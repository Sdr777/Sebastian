/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reto5p50;
import Vista.VistaRequerimientos;
/**
 *
 * @author VISION
 */
public class Reto5P50 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Requerimiento 1");
        VistaRequerimientos.requerimiento1();
        
        System.out.println("\nRequerimiento 2");
        VistaRequerimientos.requerimiento2();
        
        System.out.println("\nRequerimiento 3");
        VistaRequerimientos.requerimiento3();
    }
    
}
